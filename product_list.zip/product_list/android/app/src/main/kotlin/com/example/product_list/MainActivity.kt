package com.example.product_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
